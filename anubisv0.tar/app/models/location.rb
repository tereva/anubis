class Location < ApplicationRecord
  belongs_to :site
    
end
